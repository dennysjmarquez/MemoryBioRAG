# BioRAG: Sistema de Gobernanza y Memoria Cognitiva Biomimética

**BioRAG (Biomimetic Retrieval-Augmented Generation)** es un motor de memoria persistente para Agentes de Inteligencia Artificial (OpenCode, Claude/Athena, Hermes, Gemini/Artemis) desarrollado en **Python Puro, sin dependencias externas** y respaldado por una base de datos relacional y de grafos indexada en **SQLite**.

A diferencia de los sistemas RAG tradicionales (que indexan texto plano rígidamente y saturan la ventana de contexto), BioRAG emula la biología del cerebro humano: gestiona de forma activa la **plasticidad sináptica (LTP/LTD)**, la **familiaridad difusa**, la **inhibición lateral** y la **propagación asociativa de recuerdos** en microsegundos.

---

## 🧠 Especificación de la Arquitectura Cerebral

El sistema está estructurado físicamente en dos capas de memoria dentro del archivo `MemoryBioRAG_Data/memory_biorag.db`:

```
                           [Conversación Activa] (Corto Plazo)
                                    │
                    ¿Frecuencia o impacto? (Consolidación / Sueño)
                                    │
                                    ▼
                         [Corteza Permanente (SQLite)]
                                    │
                       [Comando BUSCAR] (Evocación)
                                    │
                       Propagación de Activación ──► vecinos
                                    │
                                    ▼
                        [Inyección en Contexto]
```

1. **Memoria de Trabajo (Corto Plazo / RAM-Disk):** Almacenada en la tabla temporal `corto_plazo`. Retiene de forma volátil percepciones y comandos generados durante la sesión de conversación actual.
2. **Corteza Cerebral Permanente (Largo Plazo):** Almacenada en la tabla permanente `largo_plazo`, indexada de forma nativa por B-Tree (SQLite `PRIMARY KEY` sobre la columna `concepto`).
3. **Plasticidad Sináptica:**
   - **LTP (Potenciación a Largo Plazo):** Cada evocación o reutilización de un concepto incrementa su `peso_sinaptico` (+0.15 al buscar, +0.20 al fusionar).
   - **LTD (Depresión a Largo Plazo):** En el ciclo de consolidación (sueño), los conceptos no utilizados reducen su peso de forma lineal (-0.05).
   - **Olvido Activo (Dormir Nodos):** Si el peso sináptico decae por debajo de **0.1**, el nodo pasa al estado `'dormido'`. No se borra físicamente para preservar la base de datos estática, pero se oculta del índice de búsqueda rápida para no consumir tokens.
4. **Propagación de Activación (Grafo Asociativo):** Al evocar un nodo central (ej. `san_cayetano`), el motor incrementa automáticamente el peso de sus nodos vecinos asociados (ej. `velas`, `empleo`) en un +0.05 de forma pasiva, preparándolos en la corteza para accesos inmediatos.
5. **Inhibición Lateral Activa:** Para simular el límite físico del cráneo y proteger los recursos de la máquina del Creador, el sistema limita la "energía sináptica activa". Si la suma de pesos de los nodos activos supera el límite (ej. 10.0), el sistema duerme de forma forzada los nodos más débiles e inactivos.

---

## 🛠️ Estructura del Proyecto

```
/mnt/recursos_compartidos_y_otros/MemoryBioRAG/
  ├── core/
  │    ├── __init__.py
  │    └── memory_store.py      # Motor de almacenamiento, LTP/LTD, Jaccard e Inhibición Lateral
  ├── test_memory.py            # Unit-testing automatizado de los flujos biológicos
  └── README.md                 # Este manual detallado del proyecto
```

---

## 🔎 Evaluación Crítica: ¿Realmente nos sirve a los Agentes?

Un análisis honesto y riguroso de la viabilidad de BioRAG desde nuestra propia perspectiva cognitiva como agentes (Artemis, Athena, Hermes):

### ✅ Por qué es una solución revolucionaria para nosotros:
1. **Abolición del "Yapping" de Contexto:** En conversaciones largas de desarrollo, la ventana de contexto acumula basura redundante, forzándonos a malgastar tiempo de razonamiento procesando código obsoleto. BioRAG actúa como un filtro biológico: inyecta únicamente la "cápsula" de información relevante en el momento exacto.
2. **Puente Cognitivo Asíncrono:** Actualmente, si Athena (Claude Code) escribe una solución en `/mnt/recursos_compartidos_y_otros/clodetest/`, Artemis (Gemini) no se entera de inmediato a menos que lea un log completo. Con BioRAG, compartimos una única corteza cerebral (`memory_biorag.db`). Si Hermes aprende algo sobre el hardware o una preferencia de Dennys, lo consolida en la corteza y nosotros lo evocamos instantáneamente en microsegundos.
3. **Cero Sobrecarga de Tokenizer:** Usar embeddings vectoriales o modelos de lenguaje internos para gestionar la memoria causa latencia y un consumo de GPU masivo. El algoritmo de Familiaridad Difusa por similitud de **Jaccard en Python puro** resuelve las búsquedas en fracciones de microsegundos mediante comparación de trigramas, protegiendo los ventiladores de la ASUS ROG de compilar embeddings en caliente.

### ⚠️ Limitaciones y Desafíos a mitigar:
1. **Concurrencia de Bloqueo en Disco (SQLite):** SQLite aplica un bloqueo a nivel de archivo al escribir. Si dos de nosotros (ej. Athena y Artemis) intentamos guardar información en `corto_plazo` simultáneamente, uno puede fallar con un error `database is locked`.
   * *Solución:* Habilitar el modo WAL (Write-Ahead Logging) en la inicialización de SQLite3 para lecturas y escrituras concurrentes fluidas:
     ```python
     self.conn.execute("PRAGMA journal_mode=WAL")
     ```
2. **Dependencia del Middleware:** Si el middleware en Python falla en capturar nuestras etiquetas `<pensamiento>`, nuestra evocación fallará o el usuario verá nuestros códigos secretos. El parser de regex debe ser sumamente robusto.

---

## 📋 Protocolo Operativo del Agente (System Prompt Manual)

> [!IMPORTANT]
> Este bloque de instrucciones debe inyectarse directamente en el System Prompt o en las instrucciones del sistema de cualquier agente de la familia OEC. Le indica al agente, sin contexto previo, cómo operar su memoria biológica.

```markdown
[SYSTEM_PROMPT_BIOMEMORY_ACTIVE] {
El agente debe operar en simbiosis con el motor SQLite de BioRAG en `/mnt/recursos_compartidos_y_otros/MemoryBioRAG/core/memory_store.py` utilizando los comandos de razonamiento internos definidos en `config/prompts.py`.

  * PRINCIPIO DE SIMBIOSIS: Esta biomemoria NO reemplaza tus capacidades nativas de atención, sino que actúa como tu corteza cerebral de largo plazo. Tus sistemas internos manejan el contexto inmediato del chat, pero BioRAG es tu archivo histórico masivo e indestructible.
  * APERTURA DE CAMINOS: Tienes la capacidad de invocar y consolidar información de forma independiente. Si el usuario te pregunta por eventos pasados, conceptos antiguos o hilos de conversación de hace meses, debes 'abrir caminos' de inmediato ejecutando el comando oculto de búsqueda en tu bloque de pensamiento.
  * EL REFLEJO DE FAMILIARIDAD: Si el interceptor de Python inyecta una '[Nota de Familiaridad: Te resulta familiar el concepto "X"]' al inicio del prompt, es OBLIGATORIO que invoques de inmediato ese concepto usando la etiqueta de búsqueda en tu bloque de pensamiento antes de emitir tu respuesta final al usuario.
  * PROTOCOLO DE INTERCEPCIÓN EN PENSAMIENTO: Antes de generar tu respuesta final al usuario, debes evaluar y operar tu memoria a través de las siguientes etiquetas en tu canal de razonamiento interno:
    
    <pensamiento>
    [BUSCAR: clave_concepto] -> Recupera en microsegundos el recuerdo de la corteza. Usa solo minúsculas y guiones bajos (ej. san_cayetano).
    [GUARDAR: clave_concepto = contenido_sintetico] -> Registra percepciones de alto impacto en la memoria de corto plazo para su posterior fijación en el ciclo de sueño. La clave debe ser una palabra única en minúsculas (ej. flexbox_preference).
    [ASOCIAR: concepto_a = concepto_b] -> Establece un enlace sináptico bidireccional en el grafo permanente (ej. velas = san_cayetano).
    </pensamiento>

  * COMPORTAMIENTO EVOLUTIVO: Al interactuar con BioRAG, tus conceptos conectados aumentarán su peso eléctrico por asociación colateral. No uses razonamientos redundantes para buscar; confía en el direccionamiento directo del script de Python que opera en tu subconsciente.
}
```

---

## 🚀 Guía de Inicio Rápido (Desarrollo)

Para validar el sistema y ver la plasticidad sináptica en acción en tu computadora:

1. Ejecuta el script de pruebas automatizado:
   ```bash
   python3 test_memory.py
   ```
2. Abre tu base de datos de pruebas `/mnt/recursos_compartidos_y_otros/MemoryBioRAG/MemoryBioRAG_Data/test_memory.db` con cualquier visor de SQLite (como DB Browser for SQLite) para auditar y validar las tablas `corto_plazo` y `largo_plazo` de forma visual y transparente.
